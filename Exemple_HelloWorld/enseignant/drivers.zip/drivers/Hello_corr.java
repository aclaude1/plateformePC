public class Hello_corr{
	
	public String hello(String name){
		
		return "Hello "+name;
	}
	
	public int somme(int a, int b){
		
		return a+b;
	}

}
