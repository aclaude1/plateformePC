public class Driver_tests{
	
	private static Hello_corr hello_corr;
	private static Hello hello_etudiant;
	
	public static void main(String[] args){
		
		hello_corr = new Hello_corr();
		hello_etudiant = new  Hello();
		
		System.out.println("<b>test hello</b>: ....."+test_hello());	
		System.out.println("<br><b>test somme</b>: ....."+test_somme());
	}
	
	private static boolean test_hello(){
		boolean res = true;
		res &= hello_corr.hello("Alex").equals(hello_etudiant.hello("Alex"));
		res &= hello_corr.hello("Vincent").equals(hello_etudiant.hello("Vincent"));
		
		return res;
	}
	
	private static boolean test_somme(){
		boolean res = true;
		res&= hello_corr.somme(1,2) == hello_etudiant.somme(1,2);
		res&= hello_corr.somme(10,-422) == hello_etudiant.somme(10,-422);
		
		return res;
	}
}
